chrome.runtime.onInstalled.addListener(() => {
  console.log("ChatGPT Question List plugin installed");
});
